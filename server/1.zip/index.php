<!DOCTYPE html>
<html>
	<head>
		<title>PHP Auto Update</title>
	</head>
	<body>
		<p>This is the test index.</p>
		<p><a href="update/index.php">Update now</a>!</p>
	</body>
</html>
